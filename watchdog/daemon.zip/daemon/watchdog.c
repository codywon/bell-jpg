#include<stdio.h> 
#include<time.h> 
#include<unistd.h>
#include<signal.h>
#include<sys/param.h>
#include<sys/types.h> 
#include<sys/stat.h> 
#include<fcntl.h>
#include<sys/ioctl.h>
#include<sys/types.h>
#if 1
#include<linux/watchdog.h>

static int fd_wdt;
#define WATCHDOG_OFF    0
#define WATCHDOG_ON     1
#define WATCHDOG_TIMER  40

watchdog_init(void)
{
        int options;
        fd_wdt = open("/dev/watchdog", O_WRONLY);

        if (fd_wdt == -1) {
                printf("Watchdog device not enabled.\n");
                return;
        }
        //options = WATCHDOG_TIMER ;
        //ioctl(fd_wdt, WDIOC_SETTIMEOUT, &options);
}

void
watchdog_handle(int state)
{
        int options;

        if (fd_wdt == -1) {
                printf("Watchdog device not enabled.\n");
                return;
        }

        if (state == WATCHDOG_ON) {
                options = WDIOS_ENABLECARD;
                ioctl(fd_wdt, WDIOC_SETOPTIONS, &options);
                printf("WDT enable.\n");
        } else if (state == WATCHDOG_OFF) {
                options = WDIOS_DISABLECARD;
                ioctl(fd_wdt, WDIOC_SETOPTIONS, &options);
                printf("WDT disable.\n");
        }
}
void
watchdog_restart(void)
{
        int dummy;

        if (fd_wdt == -1) {
                printf("Error: Watchdog device not enabled.\n");
                return;
        }

        ioctl(fd_wdt, WDIOC_KEEPALIVE, &dummy);
}

#endif

void init_daemon(void) 
{ 
	int pid; 
	int i; 

	if(pid=fork()) 
		exit(0);
	else if(pid< 0) 
		exit(1);
	setsid();
	if(pid=fork()) 
		exit(0);
	else if(pid< 0) 
		exit(1);
	return; 
} 

void GetPsFile(void){
	char 	temp[128];
	int	iRet = 0;

	memset(temp,0x00,128);
	iRet = system("ps > /tmp/gps.txt");
	iRet = system("grep -q 'thttpd' gps.txt");
	if (iRet !=0){
		system("/mnt/system/bin/thttpd -C /tmp/thttpd.conf");
	}
	iRet = system("grep -q 'encoder' gps.txt");
	if (iRet != 0){
		system("reboot");
	}
}

int main(void) 
{ 
	time_t 		pt;

	init_daemon();
	watchdog_init();
	while(1)
	{ 
		sleep(5);
		watchdog_restart();
		//pt=time(0); 
		//printf("Im here at %s\n",asctime(localtime(&pt)) ); 
	} 
} 

