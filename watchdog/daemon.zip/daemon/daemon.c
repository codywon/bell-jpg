#include<stdio.h> 
#include<time.h> 
#include<unistd.h>
#include<signal.h>
#include<sys/param.h>
#include<sys/types.h> 
#include<sys/stat.h> 
#include<fcntl.h>
#include<sys/ioctl.h>
#include<sys/types.h>
#include<linux/watchdog.h>
#include<linux/input.h>

char	keytimes 	= 0;
char	keytimes1	= 0;

static int fd_wdt;
static int key_handle;

#define WATCHDOG_ON     1

watchdog_init(void)
{
        int options;
        fd_wdt = open("/dev/HD_WATCHDOG", O_WRONLY);

        if (fd_wdt == -1) {
                printf("Watchdog device not enabled.\n");
                return;
        }
}

void watchdog_restart(void)
{
        int dummy;

        if (fd_wdt == -1) {
                printf("Error: Watchdog device not enabled.\n");
                return;
        }

        ioctl(fd_wdt, 0x0101, &dummy);
}


void init_daemon(void) 
{ 
	int pid; 
	int i; 

	if(pid=fork()) 
		exit(0);
	else if(pid< 0) 
		exit(1);
	setsid();
	if(pid=fork()) 
		exit(0);
	else if(pid< 0) 
		exit(1);
	return; 
} 

void GetPsFile(void){
	char 	temp[256];
	int	iRet = 0;
	FILE	*fp = NULL;
	char	*pdst = NULL;
	char	times = 0;

#if 0
	memset(temp,0x00,256);
	iRet = system("ps > /tmp/gps.txt");

        fp = fopen("/tmp/gps.txt","r");
        if (fp == NULL){
                printf("fopen failed\n");
                return;
        }
        fgets(temp,256,fp);
        while(!feof(fp)){
                memset(temp,0x00,256);
                fgets(temp,256,fp);
                pdst = strstr(temp,"hdencoder");
                if (pdst != NULL){
			times++;
			if (times >= 5){
				fclose(fp);
				return;
			}
                }
        }
        fclose(fp);
	if (times < 5){
		system("reboot");
	}
#endif
}

void CheckUpdate(void){
        char    temp[256];
        int     iRet = 0;
        FILE    *fp = NULL;
        char    *pdst = NULL;
        char    times = 0;
	struct stat     stStat;


	if (stat("/media/sd/system.tar", &stStat) < 0){
              	return;
      	}
	//cmp system version
	//update
        fclose(fp);
}

void GetDefaultKey(void){
        int val;
	int iRet = 0;
	char downflag = 0;

	if (fd_wdt == -1) {
                printf("Error: Watchdog device not enabled.\n");
                return;
        }

        ioctl(fd_wdt, 0x0102, &val);
	//printf("downflag %x\n",val);
	if (val == 0){
                keytimes++;
                if (keytimes >= 6){
                        keytimes = 0;
                        printf("set system param to default\n");
                        system("rm /param/system.ini");
                        system("sync");
                        system("reboot");
                }
        }else{
                keytimes = 0;
        }
}


int main(void) 
{ 
	time_t 		pt;
	unsigned short	times = 0;
	char		wdtimes = 0;
	char		updatetimes = 0;
	pthread_t       threadkey;
#if 0
        if (pthread_create(&threadkey, NULL,GetDefaultKey, NULL))
        {
              
	}

#endif
	init_daemon();
	watchdog_init();
        //watchdog_handle (WATCHDOG_ON);
	sleep(1);
	while(1)
	{ 
		sleep(1);
		GetDefaultKey();
		if (wdtimes++ >= 5){
			wdtimes = 0x00;
			watchdog_restart();
		}
		times++;
		if (times>6){
			times = 0;
			GetPsFile();
		}
		if (updatetimes++>=10){
			updatetimes = 0x00;
			CheckUpdate();
		}
		//printf("times=%d\n",times);
	} 
} 

